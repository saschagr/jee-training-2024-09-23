package hello;

import jakarta.ejb.Stateless;

@Stateless
public class GreetingBean implements Greeting {

	@Override
	public String greeting() {
		return "Huhu";
	}

}
