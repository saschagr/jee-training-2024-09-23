package singleton.zinsdienst;

import jakarta.ejb.EJB;
import jakarta.ejb.Stateless;
import jakarta.interceptor.Interceptors;

@Stateless(name = "ZinrecherMitZinssatzBean2")
@Interceptors(value = {LifeCycleMonitor.class})
public class ZinrecherMitZinssatzBean implements ZinsrechnerMitZinssatz {
	
	@EJB
	private Zinssatz zinssatz;

	@Interceptors(TraceInterceptor.class)
	public int berechneSparSumme(int anlagebetrag, int jahre) {
		double zins = zinssatz.ermittleZinssatz(anlagebetrag, jahre);
		
		return (int) (anlagebetrag * Math.pow((1+zins), jahre));
	}
}