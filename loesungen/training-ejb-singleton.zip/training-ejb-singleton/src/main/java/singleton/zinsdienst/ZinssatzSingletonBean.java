package singleton.zinsdienst;

import jakarta.ejb.ConcurrencyManagement;
import jakarta.ejb.ConcurrencyManagementType;
import jakarta.ejb.Lock;
import jakarta.ejb.LockType;
import jakarta.ejb.Singleton;
import jakarta.interceptor.Interceptors;

@Singleton
@Interceptors(value = {LifeCycleMonitor.class})
@ConcurrencyManagement(ConcurrencyManagementType.CONTAINER)
@Lock(LockType.WRITE)
public class ZinssatzSingletonBean implements Zinssatz {
	
	@Lock(LockType.READ)
	public double ermittleZinssatz(int anlagebetrag, int jahre) {
		return 0.01 * jahre;
	}
}
