package singleton.zinsdienst;

import java.util.Arrays;

import jakarta.interceptor.AroundInvoke;
import jakarta.interceptor.Interceptor;
import jakarta.interceptor.InvocationContext;

@Interceptor
public class TraceInterceptor {
	
	@AroundInvoke
	public Object trace(InvocationContext invocationContext) 
			throws Exception {
		
		
		Object returnValue = invocationContext.proceed();
		
		if (isEnabled()) {
			System.out.println(invocationContext.getTarget().getClass().getSimpleName());
			System.out.println(invocationContext.getMethod().getName());
			System.out.println(Arrays.toString(invocationContext.getParameters()));
			System.out.println(returnValue);
		}
		
		return returnValue;
	}

	private boolean isEnabled() {
		return true;
		//return Boolean.getBoolean("traceInterceptor.enabled");
	}
}
