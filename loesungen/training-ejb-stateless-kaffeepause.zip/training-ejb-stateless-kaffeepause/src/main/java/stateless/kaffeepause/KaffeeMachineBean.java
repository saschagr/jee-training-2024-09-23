package stateless.kaffeepause;

import java.util.concurrent.Future;

import jakarta.ejb.AsyncResult;
import jakarta.ejb.Asynchronous;
import jakarta.ejb.Stateless;

@Stateless
public class KaffeeMachineBean implements KaffeeMaschine {

	@Asynchronous
	@Override
	public Future<Kaffee> kocheKaffee() {
		try {Thread.sleep(10000);} catch(Exception e) {}
		return new AsyncResult<Kaffee>(new Kaffee(8));
	}

}
