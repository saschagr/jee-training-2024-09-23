/**********************************************************
* Begleitmaterial zum Buch "Enterprise JavaBeans 3.1"
* Das EJB-Praxisbuch fuer Ein- und Umsteiger
* Von Werner Eberling und Jan Lessner
* Hanser Fachbuchverlag Muenchen, 2011
* http://www.hanser.de/buch.asp?isbn=3-446-42259-5
* Feedback an ejb3buch@werner-eberling.de
**********************************************************/ 
package stateful.warenkorb;

import jakarta.ejb.Remote;

@Remote
public interface Warenkorb {
	public void legeInWarenkorb(int anzahl, String artikelnummer, int einzelpreis);

	public void entferneAusWarenkorb(String artikelnummer);

	public int geheZurKasse();
	
	public void removeMe();
}
