/**********************************************************
* Begleitmaterial zum Buch "Enterprise JavaBeans 3.1"
* Das EJB-Praxisbuch fuer Ein- und Umsteiger
* Von Werner Eberling und Jan Lessner
* Hanser Fachbuchverlag Muenchen, 2011
* http://www.hanser.de/buch.asp?isbn=3-446-42259-5
* Feedback an ejb3buch@werner-eberling.de
**********************************************************/
package hello;

@jakarta.ejb.Remote
public interface HelloWorld {

	public String hello(String who);

	public String helloGuest(String who);

	public String helloGuestAdmin(String who);
	
	public String helloGuestAdminWrong(String who);

	public String helloAdmin(String who);
}
