/**********************************************************
* Begleitmaterial zum Buch "Enterprise JavaBeans 3.1"
* Das EJB-Praxisbuch fuer Ein- und Umsteiger
* Von Werner Eberling und Jan Lessner
* Hanser Fachbuchverlag Muenchen, 2011
* http://www.hanser.de/buch.asp?isbn=3-446-42259-5
* Feedback an ejb3buch@werner-eberling.de
**********************************************************/
package hello;

import jakarta.annotation.Resource;
import jakarta.annotation.security.DenyAll;
import jakarta.annotation.security.PermitAll;
import jakarta.annotation.security.RolesAllowed;
import jakarta.ejb.SessionContext;
import jakarta.inject.Inject;
import jakarta.security.enterprise.SecurityContext;

@jakarta.ejb.Stateless
@DenyAll
public class HelloWorldSecuredBean implements HelloWorld {
	
	@Resource
	private SessionContext sessionContext;
	
	@Inject
	private SecurityContext securityContext;

	@Override
	@PermitAll
	public String hello(String who) {
		System.out.println("hello " + who);

/*
		return "Hello " + who + " - " + sessionContext.getCallerPrincipal().getName()
				+ (sessionContext.isCallerInRole("admin") ? " admin" : " kein admin ")
				+ (sessionContext.isCallerInRole("superadmin") ? " superadmin" : " kein superadmin ")
				+ (sessionContext.isCallerInRole("guest") ? " guest" : " kein guest ");
*/
		return "Hello " + who + " - " + securityContext.getCallerPrincipal().getName()
				+ (securityContext.isCallerInRole("admin") ? " admin" : " kein admin ")
				+ (securityContext.isCallerInRole("superadmin") ? " superadmin" : " kein superadmin ")
				+ (securityContext.isCallerInRole("guest") ? " guest" : " kein guest ");
	}

	@Override
	@RolesAllowed({"guest"})
	public String helloGuest(String who) {
		System.out.println("helloGuest " + who);

		return "Hello Guest " + who;
	}

	@Override
	@PermitAll
	public String helloGuestAdminWrong(String who) {
		System.out.println("helloGuestAdminWrong " + who);

		return this.helloAdmin(this.helloGuest(who));
	}

	@Override
	@PermitAll
	public String helloGuestAdmin(String who) {
		System.out.println("helloGuestAdmin " + who);
		
		
		return this.sessionContext.getBusinessObject(HelloWorld.class).helloAdmin(
				this.sessionContext.getBusinessObject(HelloWorld.class).helloGuest(who)
			
				);
	}

	@Override
	@RolesAllowed({"admin", "superadmin"})
	public String helloAdmin(String who) {
		System.out.println("helloAdmin " + who);

		return "Hello Admin " + who;
	}

}
