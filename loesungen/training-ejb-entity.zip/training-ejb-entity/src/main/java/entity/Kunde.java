package entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.OrderBy;
import jakarta.persistence.OrderColumn;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.Version;

@Entity(name = "Customer")
public class Kunde implements Serializable{
	
	@Id
	@GeneratedValue
	private int id;
	
	private String vorname;
	private String nachname;
	
	@Temporal(TemporalType.DATE)
	private Date geburtDatum;
	
	//Enum Anrede mit Frau, Herr, ...
	@Enumerated(EnumType.STRING)
	private Anrede anrede;
	
	//oder List<Telefon>
	@ElementCollection(fetch = FetchType.EAGER)
	@OrderColumn
	private List<Telefon> telefons = new ArrayList<>();

	@Version
	private int version;

	
	public Kunde() {}
	
	public Kunde(String vorname, String nachname, Date geburtDatum, Anrede anrede, List<Telefon> telefons) {
		this.vorname = vorname;
		this.nachname = nachname;
		this.geburtDatum = geburtDatum;
		this.anrede = anrede;
		this.telefons = telefons;
	}

	public Date getGeburtDatum() {
		return geburtDatum;
	}
	public void setGeburtDatum(Date geburtDatum) {
		this.geburtDatum = geburtDatum;
	}
	public List<Telefon> getTelefons() {
		return telefons;
	}
	public void setTelefons(List<Telefon> telefons) {
		this.telefons = telefons;
	}
	public int getVersion() {
		return version;
	}
	
	
	public String getVorname() {
		return vorname;
	}
	public void setVorname(String vorname) {
		this.vorname = vorname;
	}
	public String getNachname() {
		return nachname;
	}
	public void setNachname(String nachname) {
		this.nachname = nachname;
	}
	public int getId() {
		return id;
	}
	
	@Override
	public String toString() {
		return "Kunde [id=" + id + ", vorname=" + vorname + ", nachname=" + nachname + ", geburtDatum=" + geburtDatum
				+ ", anrede=" + anrede + ", telefons=" + telefons + ", version=" + version + "]";
	}
}
