package entity;

import java.util.Date;
import java.util.List;

import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

@Stateless
public class KundenDaoImpl implements KundenDAO {
	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public int erzeugeKunde(String vorname, String nachname, Date geburtDatum, Anrede anrede, List<Telefon> telefons) {
		Kunde kunde = new Kunde(vorname, nachname, geburtDatum, anrede, telefons);
		
		entityManager.persist(kunde);
		return kunde.getId();
	}

	@Override
	public Kunde findeKunde(int id) {
		return entityManager.find(Kunde.class, id);
	}

	@Override
	public Kunde aktualisiereKunde(int id, String vorname, String nachname) {
		Kunde kunde = this.findeKunde(id);
		kunde.setVorname(vorname);
		kunde.setNachname(nachname);
		return kunde;
	}

}
