package entity;

import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;

@Stateless
public class KundenDaoImpl implements KundenDAO {
	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public int erzeugeKunde(String vorname, String nachname, Date geburtDatum, Anrede anrede, List<Telefon> telefons) {
		Kunde kunde = new Kunde(vorname, nachname, geburtDatum, anrede, telefons);
		
		entityManager.persist(kunde);
		return kunde.getId();
	}

	@Override
	public Kunde findeKunde(int id) {
		Kunde kunde = entityManager.find(Kunde.class, id);
		//kunde.setTelefons(kunde.getTelefons().stream().toList());
		return kunde;
	}

	@Override
	public Kunde aktualisiereKunde(int id, String vorname, String nachname) {
		Kunde kunde = this.findeKunde(id);
		kunde.setVorname(vorname);
		kunde.setNachname(nachname);
		return kunde;
	}

	@Override
	public void einkaufen(int kundenId, Ware ware) {
		Optional.ofNullable(findeKunde(kundenId))
		.ifPresent( 
				kunde -> {
					kunde.getWarekorb().add(ware);
		});
		entityManager.merge(ware);
		
	}
	
	@Override
	public List<Kunde> findeKundeByNachname(String nachname) {
		TypedQuery<Kunde> query = 
//				entityManager.createQuery(
//						"select k from Customer k where k.nachname=:nachname", Kunde.class);
				entityManager.createNamedQuery(Kunde.QUERY_FINDE_KUNDE_BY_NACHNAME, Kunde.class);
		
		query.setParameter(Kunde.PARAM_NACHNAME, nachname);
		
		return query.getResultList();
	}

	@Override
	public List<Kunde> findeKundeByTelefonnummerAndVorname(String telefonnummer, String vorname) {
		TypedQuery<Kunde> query = 
				//entityManager.createQuery(
				//		"select k from Customer k where k.vorname=:vorname and :telefonnummer MEMBER OF k.telefons", 
				//		Kunde.class);
				entityManager.createNamedQuery(Kunde.QUERY_FINDE_KUNDE_BY_TELEFONNUMMER_AND_VORNAME, Kunde.class);
		
		query.setParameter(Kunde.PARAM_VORNAME, vorname);
		query.setParameter(Kunde.PARAM_TELEFONNUMMER, new Telefon(telefonnummer));
		
		return query.getResultList();
	}
}
