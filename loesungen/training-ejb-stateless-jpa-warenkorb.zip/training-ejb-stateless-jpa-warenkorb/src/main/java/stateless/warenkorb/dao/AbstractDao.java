package stateless.warenkorb.dao;

import jakarta.ejb.TransactionAttribute;
import jakarta.ejb.TransactionAttributeType;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

@TransactionAttribute(TransactionAttributeType.MANDATORY)
public abstract class AbstractDao<T> {

	@PersistenceContext
	private EntityManager entityManager;

	private final Class<T> entityClass;

	public AbstractDao(Class<T> entityClass) {
		this.entityClass = entityClass;
	}

	protected EntityManager getEntityManager() {
		return entityManager;
	}

	protected Class<T> getEntityClass() {
		return entityClass;
	}

	public T findById(Long primaryKey) {
		return entityManager.find(this.getEntityClass(), primaryKey);
	}

	public void remove(T entity) {
		if (entity != null) {
			if (!entityManager.contains(entity)) {
				entity = this.merge(entity);
				this.entityManager.refresh(entity);

			}
			entityManager.remove(entity);
		}
	}

	public T persist(T entity) {
		entityManager.persist(entity);
		return entity;
	}

	public T merge(T entity) {
		return entityManager.merge(entity);
	}
}
