package stateless.warenkorb.dao;

import java.util.List;

import jakarta.ejb.Stateless;
import jakarta.persistence.TypedQuery;

import stateless.warenkorb.entity.Warenkorb;


@Stateless
public class WarenkorbDao extends AbstractDao<Warenkorb> {

	public WarenkorbDao() {
		super(Warenkorb.class);
	}
	
	
	public List<Warenkorb> findWarenkorbsByArtikelnummer(String artikelnummer) {
		TypedQuery<Warenkorb> query = this.getEntityManager().createNamedQuery(Warenkorb.FIND_WARENKORBS_BY_ARTIKELNUMMER
				, Warenkorb.class);
		
		query.setParameter(Warenkorb.PARAM_ARTIKELNUMMER, artikelnummer);
		
		return query.getResultList();
		
	}

}
