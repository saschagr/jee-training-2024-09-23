/**********************************************************
* Begleitmaterial zum Buch "Enterprise JavaBeans 3.1"
* Das EJB-Praxisbuch fuer Ein- und Umsteiger
* Von Werner Eberling und Jan Lessner
* Hanser Fachbuchverlag Muenchen, 2011
* http://www.hanser.de/buch.asp?isbn=3-446-42259-5
* Feedback an ejb3buch@werner-eberling.de
**********************************************************/ 
package stateless.warenkorb;

import java.util.List;

import jakarta.ejb.Remote;

@Remote
public interface WarenkorbRemote {
	public Long erzeugeWarenkorb();

	public Long legeInWarenkorb(Long warenkorbId, int anzahl, String artikelnummer, int einzelpreis);

	public void entferneAusWarenkorb(Long warenkorbId, String artikelnummer);
	
	public List<Ware> zeigeWarenkorb(Long warenkorbId);

	public int geheZurKasse(Long warenkorbId);

}
