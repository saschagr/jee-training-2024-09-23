package stateless.warenkorb.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

@Entity
public class Log {
	
	@Id
	@GeneratedValue
	private Long id;

	private String nachricht;
	
	@Temporal(TemporalType.TIMESTAMP)
	private LocalDateTime zeitstempel;

	public Log() {
		super();
	}

	public Log(String nachricht, LocalDateTime zeitstempel) {
		super();
		this.nachricht = nachricht;
		this.zeitstempel = zeitstempel;
	}
	
}
